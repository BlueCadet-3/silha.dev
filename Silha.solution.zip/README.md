# G2 Take Home Assessment

![Martin Silha | G2 Take Home | Preview](https://i.imgur.com/9DUX3RY.jpg)
![Martin Silha | G2 Take Home | Preview](https://i.imgur.com/5IbvlDl.jpg)

---

## Technologies Used

---

* HTML

<br>

* CSS
	* [Google Fonts | Recursive](https://fonts.google.com/specimen/Recursive)
	* [Google Fonts | Roboto Slab](https://fonts.google.com/specimen/Roboto+Slab)

<br>

* JavaScript
	* [nodejs](https://nodejs.org/en/) - [[docs]](https://nodejs.org/en/docs/)
		* [Mongoose](https://www.npmjs.com/package/mongoose) - [[docs]](https://mongoosejs.com/docs/guide.html)
		* [Express](https://www.npmjs.com/package/express) - [[docs]](http://expressjs.com/en/4x/api.html)
		* [dotenv](https://www.npmjs.com/package/dotenv) - [[repo]](https://github.com/motdotla/dotenv#readme)
		* [ejs](https://www.npmjs.com/package/ejs) - [[docs]](https://ejs.co/#docs) [[repo]](https://github.com/mde/ejs#readme)
		* [node-fetch](https://www.npmjs.com/package/node-fetch) - [[repo]](https://github.com/node-fetch/node-fetch#readme)
		* [serve-favicon](https://www.npmjs.com/package/serve-favicon) - [[repo]](https://github.com/expressjs/serve-favicon#readme)

<br>

* [MongoDB Cloud](https://www.mongodb.com/cloud)

---

## Getting Started

___

It did not sound like you were too fond of the installation process, so I went ahead and [deployed it to Heroku](https://g2-silha.herokuapp.com/) if you did not want to install anything at all. It may take a minute for the app to start up since it will more than likely be idling when you go to run it.

In case that does not cut it, if this script is run inside the code directory, everything should set up to let you simply browse to [localhost:3000](http://localhost:3000) once it is done:

```zsh
npm run eugene
```

---

### In the event those do not work:

---

* Browse to code directory

* Create an .env file if it is not already there

```zsh
touch .env && echo 'DATABASE_URL=mongodb+srv://InternetPolice:EPGxKbJO8NMtZFmZ@sei.wahub.mongodb.net/g2?retryWrites=true&w=majority' >> .env
```

* Install node packages

```zsh
npm i
```

* Start the server

```zsh
npm start
```

* Browse to [localhost:3000](http://localhost:3000)

* Have fun!

___

## Next Steps

---

* Dynamically insert image width and height
* Detect broken images and set to a default image
* Create unique identifier and store in localStorage to help prevent duplicates and allow toggling of vote
* Fix phrasing for 0 or 1 vote elements
* Make preloads dynamic
