const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const voteSchema = new Schema({
	name: {
		type: String,
		required: true
	},
	userToken: {
		type: String
	},
	voteCount: {
		type: Number,
		default: 1,
		min: 1,
		max: 999999,
		required: true
	}
}, {
	timestamps: true
});

module.exports = mongoose.model('Vote', voteSchema);
