// Grab all buttons in document
const buttons = document.getElementsByTagName('button');
// Convert HTMLcollection to array
const buttonsArray = Array.from(buttons);

// Iterate through array and attach event listener to each
buttonsArray.forEach(button => {
	button.addEventListener("click", () => {
		button.innerHTML = "Thanks for voting!";
		console.log("Thanks for voting for: ", button.id);
	});
});
