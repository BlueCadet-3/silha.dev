const url = 'https://coding-assignment.g2crowd.com';

async function fetchData(url) {
	try {
		let res = await fetch(url);
		return await res.json();
	} catch (error) {
		console.error(error);
	}
}

async function renderData() {
	let data = await fetchData(url);
	let html = '';

	data.forEach(profile => {
		let htmlSegment = `
			<div class="profile-card" tabindex="0" id="${profile.name}">
				<div class="profile-image">
					<img src="${profile.image_url}" alt="Profile picture | ${profile.name}" loading="lazy" />
				</div>
				<div class="profile-info">
					<div class="profile-header">
						<h2>${profile.name}</h2>
						<h3>${profile.title}</h3>
					</div>
					<p>${profile.bio}</p>
					<br>
				<div class="profile-want">
					<p class="">Want to work with ${profile.name}?</p>
					<form method="POST" action="">
					<button type="submit">
					<img src="/images/thumbs-up.svg" width="32px" height="32px" alt="Want to work with ${profile.name}?">
					</button>
					</form>
				</div>
			</div>
			</div>`;
		html += htmlSegment;
	});

	let main = document.querySelector('main');
	main.innerHTML = html;
}

renderData();
