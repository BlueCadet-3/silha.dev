const mongoose = require('mongoose');
const Vote = require('../models/vote');

module.exports = voteCount;

async function voteCount(req, res) {
	const allVotes = await Vote.find({});
	const votes = [];
	await allVotes.forEach(profile => {
		votes.unshift(profile);
	})
	return votes;
}
