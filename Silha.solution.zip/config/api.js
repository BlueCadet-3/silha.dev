const fetch = require('node-fetch');

const g2Url = 'https://coding-assignment.g2crowd.com/';

module.exports = fetchData;

async function fetchData(url) {
	try {
		let data = await fetch(g2Url)
			.then(res => res.json())
			.then(data => data);
		return data;
	} catch (error) {
		console.error(error);
	}
}

