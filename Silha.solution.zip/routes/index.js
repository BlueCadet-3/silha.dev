const express = require('express');
const router = express.Router();
const fetchData = require('../config/api');
const fetchVotes = require('../config/votes');

/* GET home page. */
router.get('/', async function (req, res) {
  // Fetch the data from G2
  const data = await fetchData();
  // Fetch the vote count data from database
  const votes = await fetchVotes();
  // Render the view named 'index'
  res.render('index', { title: 'Martin Silha | G2 Take Home', data: data, votes: votes });
});

// Normally would have own routes file
const votesCtrl = require('../controllers/votes');
router.post('/:name/votes', votesCtrl.create);

module.exports = router;
