const Vote = require('../models/vote');
const mongoose = require('mongoose');
// In order to quickly use a method I am familiar with, but have come to find is deprecated
mongoose.set('useFindAndModify', false);

module.exports = {
	create
};

async function create(req, res) {
	// Check if vote for name already exists
	const vote = await Vote.exists({ name: req.body.name });
	// If it does, increment voteCount by 1 and redirect
	if (vote === true) {
		Vote.findOneAndUpdate({ name: req.body.name }, { $inc: { 'voteCount': 1 } }).exec();
		res.redirect('/');
		// Otherwise, create a new vote with the parameters passed with the form
	} else {
		const newVote = new Vote(req.body);
		// Save to database and redirect
		newVote.save(function (err) {
			if (err) return res.render('error');
			res.redirect('/');
		});
	}
}
